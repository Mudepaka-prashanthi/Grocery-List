// 
import React from 'react'

function Header() {
  return (
    <header>
      Grocery List
    </header>
  )
}

export default Header
